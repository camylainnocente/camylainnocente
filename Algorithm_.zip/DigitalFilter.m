function [Evento]=DigitalFilter(Evento,BFI,a)

%ECKHARDT, K. How to construct recursive digital filters for baseflow separation. Hydrological Processes, v. 19, n. 1, p. 507�515, 2005.

Evento(1,3)=Evento(1,2);
for i=2:size(Evento,1)
    value=(((1-BFI)*a*Evento(i-1,3))+((1-a)*BFI*Evento(i,2)))/(1-(a*BFI));
     if value<=Evento(i,2)
         Evento(i,3)=value;
     else
         Evento(i,3)=Evento(i,2);
     end
end

Evento(:,4)=Evento(:,2)-Evento(:,3);

end