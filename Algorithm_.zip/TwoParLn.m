function [w]=TwoParLn(Pa)

load('PMatrix');
load('Evento');
load('tb');

for t=1:tb
    h(t)=(1/sqrt(2*pi)*Pa(1)*t)*exp((-(log(t)-Pa(2))^2)/2*Pa(1)^2);
end

H=PMatrix*h';
Hidrograma=H(1:size(Evento,1));
[w]=OF(Hidrograma,Evento(:,4));

end