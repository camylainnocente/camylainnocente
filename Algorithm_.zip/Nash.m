function [w]=Nash(Pa)

load('PMatrix');
load('Evento');
load('tb');

for t=1:tb
    h(t)=(1/Pa(1))*((t/Pa(1))^(Pa(2)-1))*(1/gamma(Pa(2)))*exp(-(t/Pa(1)));
end

H=PMatrix*h';
Hidrograma=H(1:size(Evento,1));
[w]=OF(Hidrograma,Evento(:,4));

save('Hidrograma','Hidrograma');

end
