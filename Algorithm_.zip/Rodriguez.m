function [w]=Rodriguez(v)

load('PMatrix');
load('Evento');
load('Leis');
load('tb');
%Leis=[L Rl Rb Ra];
tp=0.44*(Leis(1)/v)*(Leis(3)^0.55)*(Leis(4)^-0.55)*(Leis(2)^-0.38);
beta=(0.584*(Leis(3)/Leis(4))^0.55)*(Leis(2)^0.05);

Pa(1)=(7/6)+(2*pi*beta^2);
Pa(2)=tp/(Pa(1)-1);

for t=1:tb
    h(t)=(1/Pa(1))*((t/Pa(1))^(Pa(2)-1))*(1/gamma(Pa(2)))*exp(-(t/Pa(1)));
end

H=PMatrix*h';
Hidrograma=H(1:size(Evento,1));
[w]=OF(Hidrograma,Evento(:,4));

end