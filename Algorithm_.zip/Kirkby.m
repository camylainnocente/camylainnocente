function [w]=Kirkby(Pa)

load('PMatrix');
load('Evento');
load('rio');
load('enc');
load('tb');
vr=Pa(1); %metros/dt
ve=Pa(2); %metros/dt

rio_v=rio./vr;
enc_v=enc./ve;
Aux5=rio_v+enc_v;
Aux5(Aux5==0)=NaN;

con=1;
for i=1:tb
[a,~]=find(Aux5 <= i);
tempo(con,1)=size(a,1);
con=con+1;
end

tempo(1,2)=tempo(1,1);
for i=2:size(tempo,1)
    tempo(i,2)=tempo(i,1)-tempo(i-1,1);
end

h=tempo(1:30,2);

H=PMatrix*(h./sum(h));
Hidrograma=H(1:size(Evento,1));
[w]=OF(Hidrograma,Evento(:,4));

end
