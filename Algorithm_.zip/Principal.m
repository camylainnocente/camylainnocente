%% Calibration
clear

%% Open Event
load('Evento1') 
%Evento(:,1) is rainfall (mm); 
%Evento(:,2) is Runoff (m�/s)

%% BaseFlow
BFI=0.80; %maximum baseflow index
a=0.99; %exponential decay in recession period
[Evento]=DigitalFilter(Evento,BFI,a);

%% Effective precipitation
A=5.3; %Drainage area (km�)
dT=3600; %temporal discretization of data (s)
[CN,Ia,PMatrix,EfP,Evento]=CN(Evento,A,dT);
%CN is Curve Number; 
%Ia is Initial abstraction; 
%EfP is effective precipitation
save('PMatrix','PMatrix');
save('Evento','Evento');

%% Physical parameters of watershed
Leis=[4.17 2.14 3.98 4.17]; %Geomorphological informations=[L Rl Rb Ra];
save('Leis','Leis');
P_Fisi=[4.17 2.11]; %Physical parameters=[L Lc]
save('P_Fisi','P_Fisi');

%Kikby
[fac,R] = arcgridread('fac.txt'); %Raster of flow accumulation
[fdr] = arcgridread('fdr.txt'); %Raster of flow direction
tr=100; %Treshold of area to drainage formation
%It calculates the distance from each cell to the outlet, 
%dividing between river (rio) and hillslope (enc)
[rio,enc]=dist(fac,fdr,R,tr); 

%% Unit Hydrograph
%TRADITIONAL
tb=30; %time of base [dT]
save('tb','tb')

%Traditional
%Mockus, 1957 Pa=[time of concentration]
[x10,fval0] = fminsearchbnd('Mockus',[0.1 5],[0.01 0.01],[20 20]); 
Figure(1,Evento(:,4),'Mockus - Calibration',fval0,x10)
 %Snyder, 1938 Pa=[Ct, Cp]
[x11,fval11] = fminsearchbnd('Snyder',[0.1 5],[0.01 0.01],[20 20]);
Figure(2,Evento(:,4),'Snyder - Calibration',fval11,x11)

%CONCEPTUAL
%Zoch (1934) Pa=[k]
[x20,fval20] = fminsearchbnd('Zoch',5,0.1,20); 
Figure(3,Evento(:,4),'Zoch - Calibration',fval20,x20)
%Nash (1957) Pa=[n k]
[x21,fval21] = fminsearchbnd('Nash',[0.01 0.01],[0.1 1],[5 5]);
Figure(4,Evento(:,4),'Nash - Calibration',fval21,x21) 

%PROBABILISTIC
[x30,fval30] = fminsearchbnd('TwoParLn',[0.1 -100],[0.1 -1000],[1000 1000]);
Figure(5,Evento(:,4),'TwoParLn - Calibration',fval30,x30)
[x31,fval31] = fminsearchbnd('TwoParGamma',[0.1 0.5],[0.1 0.1],[100 100]);
Figure(6,Evento(:,4),'TwoParGamma - Calibration',fval31,x31)

%GEOMORPHOLOGICAL
%Rodriguez-Iturb� (1979) Pa=[v]
[x40,fval40] = fminsearchbnd('Rodriguez',0.1,0.1,100); 
Figure(7,Evento(:,4),'Rodriguez - Calibration',fval40,x40)
%Rosso (1984) Pa=[v]
[x41,fval41] = fminsearchbnd('Rosso',1,0.1,100);
Figure(8,Evento(:,4),'Rosso - Calibration',fval41,x41) 
%Kirkby (1976) Pa=[vr ve]
[x42,fval42] = fminsearchbnd('Kirkby',[100 0.01],[0.01 0.01],[36000 18000]);  
Figure(9,Evento(:,4),'Kirkby - Calibration',fval42,x42)

%% Validation 

%Open Event
load('Evento2');

% Baseflow
BFI=0.8;
a=0.99;
[Evento]=DigitalFilter(Evento,BFI,a);

%Efective precipitation
clear CN Ia PMatrix
[CN,Ia,PMatrix,EfP,Evento]=CN(Evento,A,dT);
save('PMatrix','PMatrix');
save('Evento','Evento');

%Unit Hydrograph
%TRADITIONAL
Err(1)=Mockus(x10);
Err(2)=Snyder(x11);
%CONCEPTUAL
Err(3)=Zoch(x20);
Err(4)=Nash(x21);
%PROBABILISTIC
Err(5)=TwoParLn(x30);
Err(6)=TwoParGamma(x31);
%GEOMORPHOLOGICAL
Err(7)=Rodriguez(x40);
Err(8)=Rosso(x41);
Err(9)=Kirkby(x42);

Err