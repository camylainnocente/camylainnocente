function [w]=OF(x,y)

w = immse(x,y);

end