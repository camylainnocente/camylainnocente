function [w]=Zoch(Pa)

load('PMatrix');
load('Evento');
load('tb');

for t=1:tb
    h(t)=(1/Pa(1))*exp(-t/Pa(1));
end

H=PMatrix*h';
Hidrograma=H(1:size(Evento,1));
[w]=OF(Hidrograma,Evento(:,4));

end