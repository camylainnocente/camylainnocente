% *************************************************************************
%  SUH calibration tool
% *************************************************************************
% Authors: Innocente, C., Steiner, L.V. and Chaffe, P.L.B. 
% Developer: Camyla Innocente dos Santos
% Contact address: camylainnocente@gmail.com
% *************************************************************************
% This code or any part of it may be used as long as the authors are cited.
% Under no circumstances will authors or copyright holders be liable for any claims,
% damages or other liability arising from the use any part of related code.
% *************************************************************************
%  This code uses the following subfunction:
%           CN.m              - Calibrate the curve number method parameters
%           CN_Cal.m          - Calculates effective precipitation using 
%                               parameters already calibrated
%           DigitalFilter.m   - Numerical Filters for Hydrographs Separation
%           Figure.m          - Generates the figures
%           Kirkby.m          - Calculates Kirkby's unit hydrograph
%           Mockus.m          - Calculates Mockus's unit hydrograph
%           Nash.m            - Calculates Nash's unit hydrograph
%           OF.m              - Calculates objective function
%           Rodriguez.m       - Calculates Rodriguez's unit hydrograph
%           Rosso.m           - Calculates Rosso's unit hydrograph
%           Snyder.m          - Calculates Snyder's unit hydrograph
%           TwoParGamma.m     - Calculates unit hydrograph based in
%                               gamma distribution
%           TwoParLn.m        - Calculates unit hydrograph based in
%                               lognormal distribution
%           Zoch.m            - Calculates Zoch's unit hydrograph
% **************************************************************************
% To use SUH calibration tool use the "Principal" command (without quotes) 
