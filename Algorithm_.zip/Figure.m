function Figure(i,y,UHName,fval,x_)

figure(i)
plot(y,'r','LineWidth',1.5);
hold on
load('Hidrograma')
plot(Hidrograma,'Color',[0.5 0.5 0.5],'LineWidth',0.5)
legend('Observed','Simulated')
xlabel('Time (h)')
ylabel('Direct runoff (mm/h)')
title(UHName)
txt = {['OF =' num2str(fval)],['Parameters =' num2str(x_)]};
text(10,0.12,txt)
saveas(gcf,['Figure\',UHName],'jpeg')

end