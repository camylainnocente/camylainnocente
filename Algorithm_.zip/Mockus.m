function [w]=Mockus(P)

load('PMatrix');
load('Evento');
load('tb');

tp=0.6*P(1);
beta=P(2)*P(1);

Pa(1)=(7/6)+(2*pi*beta^2);
Pa(2)=tp/(Pa(1)-1);

for t=1:tb
    h(t)=(1/Pa(1))*((t/Pa(1))^(Pa(2)-1))*(1/gamma(Pa(2)))*exp(-(t/Pa(1)));
end

H=PMatrix*h';
Hidrograma=H(1:size(Evento,1));
[w]=OF(Hidrograma,Evento(:,4));
save('Hidrograma','Hidrograma');

end