function [w]=Rosso(v)

load('PMatrix');
load('Evento');
load('Leis');
load('tb');
%Leis=[L Rl Rb Ra];
Pa(1)=(3.29*(Leis(3)/Leis(4))^0.78)*Leis(2)^0.07;
Pa(2)=0.7*(Leis(4)/(Leis(3)*Leis(2))^0.48)*(Leis(1)/v);

for t=1:tb
    h(t)=(1/Pa(1))*((t/Pa(1))^(Pa(2)-1))*(1/gamma(Pa(2)))*exp(-(t/Pa(1)));
end

H=PMatrix*h';
Hidrograma=H(1:size(Evento,1));
[w]=OF(Hidrograma,Evento(:,4));

end
